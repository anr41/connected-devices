#!/usr/bin/env python

from lampi.lampi_app import LampiApp

if __name__ == "__main__":
    LampiApp().run()
